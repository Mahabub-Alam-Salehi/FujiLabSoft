-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 09, 2015 at 10:16 AM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: 'fujilab'
--

-- --------------------------------------------------------

--
-- Table structure for table 'branch_info'
--

DROP TABLE IF EXISTS branch_info;
CREATE TABLE branch_info (
  branch_code int(20) NOT NULL AUTO_INCREMENT,
  branch_name text NOT NULL,
  address text NOT NULL,
  phone int(20) NOT NULL,
  fax int(20) NOT NULL,
  email varchar(25) NOT NULL,
  division text NOT NULL,
  district text NOT NULL,
  PRIMARY KEY (branch_code)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'branch_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'company_info'
--

DROP TABLE IF EXISTS company_info;
CREATE TABLE company_info (
  company_id int(25) NOT NULL AUTO_INCREMENT,
  company_name text NOT NULL,
  short_name text NOT NULL,
  address text NOT NULL,
  phone int(20) NOT NULL,
  fax int(20) NOT NULL,
  email_address varchar(40) NOT NULL,
  url varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (company_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table 'company_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'current_stock'
--

DROP TABLE IF EXISTS current_stock;
CREATE TABLE current_stock (
  product_code int(25) NOT NULL DEFAULT '0',
  product_name text NOT NULL,
  branch_code int(25) NOT NULL,
  address text NOT NULL,
  stock_quantity int(25) NOT NULL,
  created_by text NOT NULL,
  creation_date date NOT NULL,
  updated_by text NOT NULL,
  update_date date NOT NULL,
  PRIMARY KEY (product_code)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'current_stock'
--


-- --------------------------------------------------------

--
-- Table structure for table 'daily_expense_info'
--

DROP TABLE IF EXISTS daily_expense_info;
CREATE TABLE daily_expense_info (
  expense_code int(25) NOT NULL AUTO_INCREMENT,
  branch_code int(25) NOT NULL,
  expense_name text NOT NULL,
  expense_date date NOT NULL,
  amount int(25) NOT NULL,
  address text NOT NULL,
  ref_no int(20) NOT NULL,
  PRIMARY KEY (expense_code)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table 'daily_expense_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'group_info'
--

DROP TABLE IF EXISTS group_info;
CREATE TABLE group_info (
  group_id int(25) NOT NULL AUTO_INCREMENT,
  group_name text NOT NULL,
  branch_name text NOT NULL,
  product_name text NOT NULL,
  quantity int(25) NOT NULL,
  PRIMARY KEY (group_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table 'group_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'product_info'
--

DROP TABLE IF EXISTS product_info;
CREATE TABLE product_info (
  p_id int(25) NOT NULL AUTO_INCREMENT,
  product_code varchar(25) NOT NULL,
  group_code varchar(25) NOT NULL,
  challan_no varchar(25) NOT NULL,
  product_name text NOT NULL,
  description text NOT NULL,
  `date` date NOT NULL,
  product_price int(50) NOT NULL,
  unit_price int(50) NOT NULL,
  total_length int(40) NOT NULL,
  set_price int(50) NOT NULL,
  supplier_address text NOT NULL,
  PRIMARY KEY (p_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'product_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'prod_issue_to_branch_info'
--

DROP TABLE IF EXISTS prod_issue_to_branch_info;
CREATE TABLE prod_issue_to_branch_info (
  issue_no int(25) NOT NULL AUTO_INCREMENT,
  issue_date date NOT NULL,
  issue_from varchar(25) NOT NULL,
  issue_from_add text NOT NULL,
  issue_to varchar(25) NOT NULL,
  issue_to_address text NOT NULL,
  product_code int(20) NOT NULL,
  product_name varchar(50) NOT NULL,
  unit_price int(20) NOT NULL,
  stock_quantity int(20) NOT NULL,
  issue_quantity int(20) NOT NULL,
  PRIMARY KEY (issue_no)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'prod_issue_to_branch_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'sales_info'
--

DROP TABLE IF EXISTS sales_info;
CREATE TABLE sales_info (
  p_id int(20) NOT NULL,
  product_name text NOT NULL,
  branch_code int(20) NOT NULL,
  sales_date date NOT NULL,
  stock_quantity int(20) NOT NULL,
  unit_price int(20) NOT NULL,
  amount int(20) NOT NULL,
  net_amount int(25) NOT NULL,
  discount int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'sales_info'
--


-- --------------------------------------------------------

--
-- Table structure for table 'user_info'
--

DROP TABLE IF EXISTS user_info;
CREATE TABLE user_info (
  u_id int(25) NOT NULL AUTO_INCREMENT,
  u_name text NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (u_id)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table 'user_info'
--

INSERT INTO user_info (u_id, u_name, password) VALUES(1, 'root', '123');
